
<?php

$db = new mysqli("localhost","root","Umesh@123","app");

if($db->connect_error)
{
	echo "Database not connected";
}
else{
	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		$fname = $_POST['fname'];
		$fnumber = $_POST['fnumber'];
		$femail = $_POST['femail'];
		$message = $_POST['message'];
		
		

			$store_user = "INSERT INTO contact(fname,mo_number,email,message)
			VALUES('$fname','$fnumber','$femail','$message')";

			if($db->query($store_user))
				{
					echo "accepted";
				}
			else{
				echo "failed";
			}
	

	
	}
}


?>