<!DOCTYPE html>
<html>
<head>
	<title>image processing</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1" >
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	<style>
		*:focus{
			box-shadow: none !important;
			outline: none !important;
		}
	</style>
</head>
<body  style="background: #FCD0CF" class="animated fadeIn slower">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-4 p-0">
				<img src="images/main_pic.jpg" class="shadow-lg w-100">
			</div>
			<div class="col-md-4 px-5 py-4">
				<h3 class="ml-2 mb-3">SIGN UP</h3>
				<form method="post" action="register.php" autocomplete="off" >
				
					<input type="text"  name="fullname" class="form-control mb-5" placeholder="Type your name" required="required">
					<input type="email"  name="email" class="form-control mb-5" placeholder="Type your name" required="required">
					<input type="password"  name="password" class="form-control mb-5" placeholder="Type your name" required="required">
					<input type="submit" class="btn btn-primary submit-btn" value="submit now">
				</form>



				</div>
				<div class="col-md-4 px-5 py-4">
					<h3 class="ml-2 mb-3">Login</h3>
					<form method="post" action="login.php" autocomplete="off">
					<input type="email" name="username" class="form-control mb-5"  placeholder="USERNAME" required="required">		
					<input type="password" name="password" class="form-control mb-5" placeholder="PASSWORD" required="required">
					<input type="submit" class="btn btn-primary login-btn" value="Login">
		
					</form>
				</div>
			</div>
		</div>
	
	
	
	
</body>
</html>