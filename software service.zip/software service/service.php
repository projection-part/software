<nav class="navbar navbar-expand-md bg-dark navbar-dark ">
		<ul class=" ml-auto navbar-nav">
			<li class="nav-item">
				<a href="#" class="nav-link">
					Services
				</a>
			</li>
		</ul>
		<ul class=" ml-auto navbar-nav">
			<li class="nav-item">
				<a href="#" class="nav-link">
					images
				</a>
			</li>
		</ul>
		<ul class=" ml-auto navbar-nav">
			<li class="nav-item">
				<a href="#" class="nav-link">
					videos
				</a>
			</li>
		</ul>


		<ul class=" ml-auto navbar-nav">
			<li class="nav-item">
				<a href="logout.php" class="nav-link">
					<i class="fa fa-sign-out" style="font-size: 18px"></i>
					Logout
				</a>
			</li>
		</ul>

	</nav>





<div class="container-fluid">
		<div class="row">
			<div class="col-md-3 p-5 border">
				<div class="d-flex flex-column justify-content-center align-items-center rounded-lg w-100 bg-white shadow-lg mb-5" style="height:250px;">
					<i class="fa fa-folder-open upload-icon" style="font-size: 100px;"></i>
					<h4 class="upload-header">UPLOAD FILES</h4>
					<span class="free-space">
						<?php
							$get_status = "SELECT plans,storage,used_storage FROM users WHERE username = '$username'";
							$response = $db->query($get_status);
							$data = $response->fetch_assoc();
							$total = $data['storage'];
							$used = $data['used_storage'];
							$plans = $data['plans'];
							if($plans =="starter" || $plans=="free")
							{
							$free_space = $total-$used;
							echo "FREE SPACE : ".$free_space."MB";
							}
							else{
								echo "FREE SPACE : UNLIMITED";
							}
						?>
					</span>
					<div class="progress upload-progress-con d-none w-50 my-2" style="height: 5px;">
						<div class="progress-bar progress-bar-animated progress-bar-stripped progress-control"></div>
					</div>
					<div class="progress-details d-none">
						<span class="progress-percentage"></span>
						<i class="fa fa-pause-circle"></i>
						<i class="fa fa-times-circle"></i>
					</div>
				</div>

				<div class="d-flex flex-column justify-content-center align-items-center rounded-lg w-100 bg-white shadow-lg mb-5" style="height:250px;">
					<i class="fa fa-database" style="font-size: 100px;"></i>
					<h4>MEMORY STATUS</h4>
					<span class="memory-status"> 
						<?php
							$get_status = "SELECT plans,storage,used_storage FROM users WHERE username = '$username'";
							$response = $db->query($get_status);
							$data = $response->fetch_assoc();
							$total = $data['storage'];
							$used = $data['used_storage'];
							$plans = $data['plans'];
							if($plans=="starter" || $plans=="free")
							{
								$display = "d-block";
							echo $used." MB/".$total." MB";
							$percentage = round(($used*100)/$total,2);
							$color = "";
							if($percentage>80)
							{
								$color = "bg-danger";
							}
							else{
								$color = "bg-primary";
							}
						}
						else{
							echo "Used storage".$used." MB";
							$display = "d-none";
						}

						?>

					</span>
					
					<div class="progress w-50 my-2 <?php echo $display;?>" style="height: 5px;">
						<div class="progress-bar memory-progress <?php echo $color; ?>" style="width: <?php echo $percentage.'%'; ?>">
							
							<?php
							echo $percentage;
							?>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-6 p-5 border"></div>
			<div class="col-md-3 p-5 border">
				<div class="d-flex flex-column justify-content-center align-items-center rounded-lg w-100 bg-white shadow-lg mb-5" style="height:250px;">
					<a href="gallery.php" class="image-link"><i class="fa fa-image text-primary" style="font-size: 80px;"></i></a>
					<h4>GALLERY</h4>
					
					<div>
						<span class="count-photo">
							<?php
							$get_id = "SELECT id FROM users WHERE username = '$username'";
							$response = $db->query($get_id);
							$data = $response->fetch_assoc();
							$table_name = "user_".$data['id'];
							$count_photo = "SELECT COUNT(id) AS total FROM $table_name";
							$response_photo = $db->query($count_photo);
							$data = $response_photo->fetch_assoc();
							echo $data['total']." PHOTOS";
							$_SESSION['table_name'] = $table_name;
							?>
						</span>
						
					</div>

				</div>
				<div class="d-flex flex-column justify-content-center align-items-center rounded-lg w-100 bg-white shadow-lg mb-5" style="height:250px;">
					<a href="shop.php" class="memory-link"><i class="fa fa-shopping-cart text-primary" style="font-size: 100px;"></i></a>
					<h4>MEMORY SHOPPING</h4>
					<span>START FROM <i class="fa fa-inr"></i>99.00/mo</span>
				</div>
			</div>
		</div>
	</div>