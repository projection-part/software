<?php

$db = new mysqli("localhost","root","Umesh@123","app");

if($db->connect_error)
{
	echo "Database not connected";
}
else{
	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		$username = $_POST['username'];
		$password = md5($_POST['password']);
		$check_user = "SELECT username FROM users WHERE username = '$username'";
		$response = $db->query($check_user);
		if($response->num_rows == 1)
		{
			$check_pasword = "SELECT password FROM users WHERE password = '$password'";
			$pwd_response = $db->query($check_pasword);
			if($pwd_response->num_rows == 1)
			{
				header("Location:hello.php");
			}
			else{
				echo "Wrong password";
			}
		}
		else{
			echo "User not found";
		}
	}
}




?>