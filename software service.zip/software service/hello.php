<?php

session_start();



?>


<!DOCTYPE html>
<html>
<head>
	<title>profile page</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1" >
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	
</head>
<body  style="background: #FCD0CF" class="animated fadeIn slower">
	<nav class="navbar navbar-expand-md bg-dark navbar-dark ">
		<ul class=" ml-auto navbar-nav">
			<li class="nav-item">
				<a href="service.php" class="nav-link">
					Services
				</a>
			</li>
		</ul>
		<ul class=" ml-auto navbar-nav">
			<li class="nav-item">
				<a href="#" class="nav-link">
					images
				</a>
			</li>
		</ul>
		<ul class=" ml-auto navbar-nav">
			<li class="nav-item">
				<a href="#" class="nav-link">
					videos
				</a>
			</li>
		</ul>


		<ul class=" ml-auto navbar-nav">
			<li class="nav-item">
				<a href="logout.php" class="nav-link">
					<i class="fa fa-sign-out" style="font-size: 18px"></i>
					Logout
				</a>
			</li>
		</ul>

	</nav>
	<div class="container">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-6">
		<form method="POST" action="feedback.php"><br>
		<h2>Contact Us</h2>
					<input type="text" name="fname" class="form-control mb-4" placeholder="Your name">
					<input type="number" name="fnumber" class="form-control mb-4" placeholder="Mobile number">
					<input type="email" name="femail" class="form-control mb-4" placeholder="Your email">
					<textarea rows="10" cols="70" name="message" class="p-1 mb-4">message...
						
					</textarea>
					<input type="submit" class="btn btn-primary submit-btn" value="Send">
			
		</form>
	</div>
	<div class="col-md-6"></div>
	</div>
	</div>
</body>
</html>